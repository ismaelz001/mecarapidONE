import Sidebar from './Sidebar';
export default function Shell({children}:{children:any}){
  return <div style={{display:'flex'}}><Sidebar/><main>{children}</main></div>
}
