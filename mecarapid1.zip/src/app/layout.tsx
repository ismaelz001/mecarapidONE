import { Rajdhani } from 'next/font/google';
const rajdhani = Rajdhani({ subsets: ['latin'], weight: ['500','600','700'] });

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body className={rajdhani.className + ' bg-mr-bg text-mr-text'}>
        {children}
      </body>
    </html>
  );
}
